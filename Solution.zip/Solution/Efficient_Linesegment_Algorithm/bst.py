count = [10]


class Node:
    def __init__(self, key, val, left=None, right=None,
                 parent=None):
        self.key = key
        self.value = val
        self.left = left
        self.right = right
        self.parent = parent

    def has_left_child(self):
        return self.left

    def has_right_child(self):
        return self.right

    def is_left(self):  # if there is a parent and the parents left node is this node
        return self.parent and self.parent.left == self

    def is_right(self):  # if there is a parent and the parents right node is this node
        return self.parent and self.parent.right == self

    def is_root(self):  # if there is no parent then its a root
        return not self.parent

    def is_leaf(self):  # if there are no children then it is a leaf node
        return not (self.left or self.right)

    def singleChild(self):
        return self.right or self.left

    def bothChildren(self):
        return self.right and self.left

    def replaceData(self, key, value, l, r):
        self.key = key
        self.value = value
        self.left = l
        self.right = r
        if self.has_left_child():
            self.left.parent = self
        if self.has_right_child():
            self.right.parent = self

    def spliceOut(self):
        if self.is_leaf():
            if self.is_left():
                self.parent.left = None
            else:
                self.parent.right = None
        elif self.singleChild():
            if self.has_left_child():
                if self.is_left():
                    self.parent.left = self.left
                else:
                    self.parent.right = self.left
                self.left.parent = self.parent
            else:
                if self.is_left():
                    self.parent.left = self.right
                else:
                    self.parent.right = self.right
                self.right.parent = self.parent

    def findSuccessor(self):
        successor = None
        if self.has_right_child():
            successor = self.right.findMin()
        else:
            if self.parent:
                if self.is_left():
                    successor = self.parent
                else:
                    self.parent.right = None
                    successor = self.parent.findSuccessor()
                    self.parent.right = self
        return successor

    def findPredecessor(self):
        predecessor = None
        if self.has_left_child():
            return self.left.findMax()
        else:
            current = self
            predecessor = self.parent
            while predecessor is not None:
                if current == predecessor.right:
                    break
                current = predecessor
                predecessor = predecessor.parent
            return predecessor

    def findMin(self):
        current = self
        while current.has_left_child():
            current = current.left
        return current

    def findMax(self):
        current = self
        while current.has_right_child():
            current = current.right
        return current


class BinarySearchTree:

    def __init__(self):
        self.root = None
        self.size = 0

    def length(self):
        return self.size

    def __len__(self):
        return self.size

    def __iter__(self):
        return self.root.__iter__()

    def insert_key(self, key, value):
        if self.root:  # if there is a root, insert the new key-value pair attached to the root
            self._insert_key(key, value, self.root)
        else:  # create root if root is not there
            self.root = Node(key, value)
        self.size = self.size + 1

    def _insert_key(self, key, value, curNode):  # attach key to current node
        if key < curNode.key:
            if curNode.has_left_child():  # if current node contains a left child, attach new node to the leftchild
                self._insert_key(key, value, curNode.left)
            else:  # if current node dont have left child, create a new node to the left with the new key value pair
                curNode.left = Node(key, value, parent=curNode)
        else:
            if curNode.has_right_child():
                self._insert_key(key, value, curNode.right)
            else:
                curNode.right = Node(key, value, parent=curNode)

    def print_tree(self):
        if self.root:
            self._print_tree(self.root)

    def _print_tree(self, curNode):
        if curNode.has_left_child():
            self._print_tree(curNode.left)
        print(curNode.key, end='   ')
        if curNode.has_right_child():
            self._print_tree(curNode.right)

    def print2d(self):
        if self.root:
            self._print2d(self.root, 0)

    def _print2d(self, curNode, space):
        space += count[0]
        if curNode.has_right_child():
            self._print2d(curNode.right, space)
        # print()
        for i in range(count[0], space):
            print(end=" ")
        print(curNode.key)
        if curNode.has_left_child():
            self._print2d(curNode.left, space)

    def getSuccessor(self, key):
        curNode = self.__retrieve(key, self.root)
        if curNode.findSuccessor() is not None:
            return curNode.findSuccessor().key, curNode.findSuccessor().value
        else:
            return None

    def getPredecessor(self, key):
        curNode = self.__retrieve(key, self.root)
        if curNode.findPredecessor() is not None:
            return curNode.findPredecessor().key, curNode.findPredecessor().value
        else:
            return None

    # get value(points of the corresponding key ie ponints of the corresponding rectangle to check intersection)
    # implementation
    def __getvalue__(self, key):
        return self.retrieve(key)

    def retrieve(self, key):
        if self.root:  # if there is a root
            result = self.__retrieve(key, self.root)  # passing root to search the tree
            if result:
                return result.value
            else:
                return None
        else:
            return None

    def __retrieve(self, key, curNode):
        if not curNode:
            return None
        elif curNode.key == key:
            return curNode
        elif key < curNode.key:  # if new value is less than key, search left subtree
            return self.__retrieve(key, curNode.left)
        else:  # if value is greater than current key value, search right subtree
            return self.__retrieve(key, curNode.right)

    # Delete node
    def deleteKey(self, key):
        if self.size > 1:  # tree has a root - pass root so that it searches entire tree
            nodeTobeRemoved = self.__retrieve(key, self.root)
            if nodeTobeRemoved:
                self.remove(nodeTobeRemoved)
                self.size = self.size - 1
            else:
                raise KeyError('Entered key not in the tree')
        elif self.size == 1 and self.root.key == key:  # if given key is root
            self.root = None
            self.size = self.size - 1
        else:
            raise KeyError('Entered key not in the tree')

    def __delete_Key(self, key):
        self.deleteKey(key)

    def remove(self, curNode):
        if curNode.is_leaf():
            if curNode == curNode.parent.left:  # if its left leaf, remove the leaf
                curNode.parent.left = None
            else:
                curNode.parent.right = None

        elif curNode.bothChildren():    #current node has both children
            successor = curNode.findSuccessor()
            curNode.key = successor.key
            curNode.value = successor.value
            successor.spliceOut()

        else:  # current node has one child
            if curNode.has_left_child():
                if curNode.is_left():
                    curNode.left.parent = curNode.parent
                    curNode.parent.left = curNode.left
                elif curNode.is_right():
                    curNode.left.parent = curNode.parent
                    curNode.parent.right = curNode.left
                else:  # current node is root
                    curNode.replaceData(curNode.left.key, curNode.left.value, curNode.left.left, curNode.left.right)
            else:
                if curNode.is_left():
                    curNode.right.parent = curNode.parent
                    curNode.parent.left = curNode.right
                elif curNode.is_right():
                    curNode.right.parent = curNode.parent
                    curNode.parent.right = curNode.right
                else:
                    curNode.replaceData(curNode.right.key, curNode.right.value, curNode.right.left, curNode.right.right)


'''
for testing purpose

mytree = BinarySearchTree()
mytree.insert_key(15, 1)
mytree.insert_key(20, 2)
mytree.insert_key(10, 3)
mytree.insert_key(12, 4)
mytree.insert_key(1, 5)
mytree.insert_key(40, 6)
mytree.insert_key(2, 7)
mytree.insert_key(30, 8)
mytree.insert_key(50, 8)

mytree.print2d()

print("delete function")
# mytree.deleteKey(40)
mytree.print2d()
print("the key of pred is")
print(mytree.getPredecessor(50))
'''
