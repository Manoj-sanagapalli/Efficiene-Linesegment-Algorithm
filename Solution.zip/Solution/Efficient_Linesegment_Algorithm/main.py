import numpy
import sys
import pandas as pd
from math import sqrt
import time
# importing the data from given file

map_data = numpy.loadtxt('map.mat')
data = pd.DataFrame(data=map_data, index=None, columns=None)
data = data.append(pd.Series(), ignore_index=True)

# values for testing the algorithm

d_lower = 60
d_upper = 700
given_point = [0, 0]


def Distance(S, E, X):
    # defining vectors
    V_SE = [(E[0] - S[0]), (E[1] - S[1])]
    V_EX = [(X[0] - E[0]), (X[1] - E[1])]
    V_SX = [(X[0] - S[0]), (X[1] - S[1])]
    # obtaining dot product
    SE_EX = V_SE[0] * V_EX[0] + V_SE[1] * V_EX[1]
    SE_SX = V_SE[0] * V_SX[0] + V_SE[1] * V_SX[1]
    if SE_EX > 0:  # the closes point will be E
        distance = sqrt(V_EX[0] * V_EX[0] + V_EX[1] * V_EX[1])
    elif SE_SX < 0:  # the closest point will be S
        distance = sqrt(V_SX[0] * V_SX[0] + V_SX[1] * V_SX[1])
    else:  # if the point lies perpendicular to the line
        # cross product
        SeXSx = V_SE[0] * V_SX[1] - V_SE[1] * V_SX[0]
        length = sqrt(V_SE[0] * V_SE[0] + V_SE[1] * V_SE[1])
        if (length == 0):
            distance = sys.float_info.max  # invalid input in the file. line cannot be formed with given points
        else:
            distance = abs(SeXSx) / length
    return distance


def relativeDistances(P, Q, R, S):
    # assuming general equation of line y = mx + c
    # slope of PQ
    if (Q[1] - P[1] == 0): #line formed is in the form y=c
        slope1 = 0
        c1 = Q[1]
    else:
        if Q[0] - P[0] == 0:  # line formed is in the form x = c
            c1 = 0;
            slope1 = sys.float_info.max;  #slope infinity for line parallel to y axis
        else:
            slope1 = (Q[1] - P[1]) / (Q[0] - P[0])
            c1 = P[1] - slope1 * P[0]
    # slope of RS
    if (S[1] - R[1] == 0): #line formed is in the form y=c
        slope2 = 0
        c2 = S[1]
    else:
        if S[0] - R[0] == 0:  # line formed is in the form x = c
            c2 = 0;
            slope2 = sys.float_info.max;
        else:
            slope2 = (S[1] - R[1]) / (S[0] - R[0])
            c2 = R[1] - slope2 * R[0]

    # Parallel case
    if slope1 == slope2:
        #print("parellel")
        if c1 == c2:  # lines are collinear
            S_mindistance = Distance(P, Q, R)
            E_mindistance = Distance(P, Q, S)
            if S_mindistance <= E_mindistance:
                return S_mindistance
            else:
                return E_mindistance
        else:
            return abs(c2 - c1) / sqrt(slope1 * slope1 + 1)

    # Intersecting case
    # find intersecting point's x co-ordinate
    # m1x+c1 = m2x+c2
    x_intersect = (c2 - c1) / (slope1 - slope2)
    lower_limit = max(min(P[0], Q[0]), min(R[0], S[0]))
    upper_limit = min(max(P[0], Q[0]), max(R[0], S[0]))

    if lower_limit < x_intersect < upper_limit:  # Intersecting lines
        return 0
    else:
        S_mindistance = Distance(P, Q, R)
        E_mindistance = Distance(P, Q, S)

        if S_mindistance <= E_mindistance:
            return S_mindistance
        else:
            return E_mindistance


if __name__ == '__main__':
    for i in range(len(data.columns)):
        X_si = data.iloc[0, i]
        X_ei = data.iloc[1, i]
        Y_si = data.iloc[2, i]
        Y_ei = data.iloc[3, i]
        start_point = [X_si, Y_si]
        end_point = [X_ei, Y_ei]
        # getting distances to all the lines and storing them
        data.loc[4, i] = Distance(start_point, end_point, given_point)
        if Distance(start_point, end_point, given_point) == sys.float_info.max:
            print("Invalid input given at column no:", i, ", line cannot be formed")
    minimum_distance = data.iloc[4, :].min()
    # getting the data corresponding to the line with minimum distance
    for i in range(len(data.columns)):
        if data.iloc[4, i] == minimum_distance:
            print("1. The closest line to the given point is formed by points ",
                  ("S", i, data.iloc[0, i], data.iloc[2, i]), "and", (data.iloc[1, i], data.iloc[3, i]))
            print("-------------------------------------------------------------------------------------")

    print("2. The set of lines within the given distance limits are formed by points")
    for i in range(len(data.columns)):
        if d_lower < data.iloc[4, i] < d_upper:
            print("S", i, ".", (data.iloc[0, i], data.iloc[2, i]), ",",
                  (data.iloc[1, i], data.iloc[3, i]), "and the distance is", data.iloc[4, i])
    print("-------------------------------------------------------------------------------------")

    start_time= time.time()
    line_pairs = []  # declaring a empty array to store line pairs

    # iterating through all possible pair combinations
    for i in range(len(data.columns)):
        Si_start = [data.iloc[0, i], data.iloc[2, i]]
        Si_end = [data.iloc[1, i], data.iloc[3, i]]

        for j in range(len(data.columns) - i):
            Sj_start = [data.iloc[0, i + j], data.iloc[2, i + j]]
            Sj_end = [data.iloc[1, i + j], data.iloc[3, i + j]]

            # finding the relative distance between a pair of lines
            rel_d = relativeDistances(Si_start, Si_end, Sj_start, Sj_end)
            if (rel_d <= d_lower) and (i != i+j):
                line_pairs.append((i, i + j))

    end_time = time.time()
    print("3. The pairs of line segments Si,Sj whose relative distance is lower than given d_lower are :")
    print(line_pairs)
    print("size ", len(line_pairs))
    print("-------------------------------------------------------------------------------------")
    print("time = ", end_time-start_time)
