import numpy
import sys
import pandas as pd
from math import sqrt
import time
import bst

d_lower = 10


def Distance(S, E, X):
    # defining vectors
    V_SE = [(E[0] - S[0]), (E[1] - S[1])]
    V_EX = [(X[0] - E[0]), (X[1] - E[1])]
    V_SX = [(X[0] - S[0]), (X[1] - S[1])]
    # obtaining dot product
    SE_EX = V_SE[0] * V_EX[0] + V_SE[1] * V_EX[1]
    SE_SX = V_SE[0] * V_SX[0] + V_SE[1] * V_SX[1]
    if SE_EX > 0:  # the closes point will be E
        distance = sqrt(V_EX[0] * V_EX[0] + V_EX[1] * V_EX[1])
    elif SE_SX < 0:  # the closest point will be S
        distance = sqrt(V_SX[0] * V_SX[0] + V_SX[1] * V_SX[1])
    else:  # if the point lies perpendicular to the line
        # cross product
        SeXSx = V_SE[0] * V_SX[1] - V_SE[1] * V_SX[0]
        length = sqrt(V_SE[0] * V_SE[0] + V_SE[1] * V_SE[1])
        if (length == 0):
            distance = sys.float_info.max  # invalid input in the file. line cannot be formed with given points
        else:
            distance = abs(SeXSx) / length
    return distance


def relativeDistances(P, Q, R, S):
    # assuming general equation of line y = mx + c
    # slope of PQ
    if (Q[1] - P[1] == 0):  # line formed is in the form y=c
        slope1 = 0
        c1 = Q[1]
    else:
        if Q[0] - P[0] == 0:  # line formed is in the form x = c
            c1 = 0;
            slope1 = sys.float_info.max;  # slope infinity for line parallel to y axis
        else:
            slope1 = (Q[1] - P[1]) / (Q[0] - P[0])
            c1 = P[1] - slope1 * P[0]
    # slope of RS
    if (S[1] - R[1] == 0):  # line formed is in the form y=c
        slope2 = 0
        c2 = S[1]
    else:
        if S[0] - R[0] == 0:  # line formed is in the form x = c
            c2 = 0;
            slope2 = sys.float_info.max;
        else:
            slope2 = (S[1] - R[1]) / (S[0] - R[0])
            c2 = R[1] - slope2 * R[0]

    # Parallel case
    if slope1 == slope2:
        # print("parellel")
        if c1 == c2:  # lines are collinear
            S_mindistance = Distance(P, Q, R)
            E_mindistance = Distance(P, Q, S)
            if S_mindistance <= E_mindistance:
                return S_mindistance
            else:
                return E_mindistance
        else:
            return abs(c2 - c1) / sqrt(slope1 * slope1 + 1)

    # Intersecting case
    # find intersecting point's x co-ordinate
    # m1x+c1 = m2x+c2
    x_intersect = (c2 - c1) / (slope1 - slope2)
    min_1 = min(P[0], Q[0])
    min_2 = min(R[0], S[0])
    max_1 = max(P[0], Q[0])
    max_2 = max(R[0], S[0])
    lower_limit = max(min_1, min_2)
    upper_limit = min(max_1, max_2)

    if lower_limit < x_intersect < upper_limit:  # Intersecting lines
        return 0
    else:
        S_mindistance = Distance(P, Q, R)
        E_mindistance = Distance(P, Q, S)

        if S_mindistance <= E_mindistance:
            return S_mindistance
        else:
            return E_mindistance


# class to store points
class Point:
    # tags for left point and right point
    isleft = False
    isright = False

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return "Point({}, {}), left ={} , right = {}".format(self.x, self.y, self.isleft, self.isright)


# class to store lines
class Line:
    def __init__(self, p1, p2, idx):
        self.p1 = p1
        self.p2 = p2
        self.idx = idx

    def min_dist(self, other, _last=False):
        Si_start = [self.p1.x, self.p1.y]
        Si_end = [self.p2.x, self.p2.y]
        Sj_start = [other.p1.x, other.p1.y]
        Sj_end = [other.p2.x, other.p2.y]
        return relativeDistances(Si_start, Si_end, Sj_start, Sj_end)

    def __repr__(self):
        return "Line(({}, {}) -> ({}, {})".format(self.p1.x, self.p1.y, self.p2.x, self.p2.y)


# class to for rectangle from boundary conditions
class Rectangle:
    left_point = Point(0, 0)
    right_point = Point(0, 0)
    maximun_y = 0

    def __init__(self, linep1, linep2, p1, p2, p3, p4, idx):
        self.p1 = p1
        self.p2 = p2
        self.p3 = p3
        self.p4 = p4
        self.idx = idx
        self.linep1 = linep1
        self.linep2 = linep2
        self.maximun_y = max(self.p1.y, self.p2.y, self.p3.y, self.p4.y)
        # find left most point of the given rectangle and setting flag to that point
        if min(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p1.x:
            self.p1.isleft = True
            self.left_point = p1
        elif min(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p2.x:
            self.p2.isleft = True
            self.left_point = p2
        elif min(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p3.x:
            self.p3.isleft = True
            self.left_point = p3
        elif min(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p4.x:
            self.p4.isleft = True
            self.left_point = p4

        # find right most point of the given rectangle and set flag to that point
        if max(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p1.x:
            self.p1.isright = True
            self.right_point = p1
        elif max(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p2.x:
            self.p2.isright = True
            self.right_point = p2
        elif max(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p3.x:
            self.p3.isright = True
            self.right_point = p3
        elif max(self.p1.x, self.p2.x, self.p3.x, self.p4.x) == self.p4.x:
            self.p4.isright = True
            self.right_point = p4

    def __repr__(self):
        return "Max y - {}".format(self.maximun_y)
        # return "ID- {},{},{},{},{}".format(self.idx, self.p1, self.p2, self.p3, self.p4)


# check if the rectangles intersect
def check_intersection(p1, p2, p3, p4, p5, p6, p7, p8):
    l1 = []
    l2 = []
    l1.append([Line(p1, p2, 1), Line(p2, p3, 2), Line(p3, p4, 3), Line(p4, p1, 4)])
    l2.append([Line(p5, p6, 5), Line(p6, p7, 6), Line(p7, p8, 7), Line(p8, p5, 8)])
    intersection = False
    for k in l1[0]:
        for j in l2[0]:
            if k.min_dist(j) == 0:
                intersection = True
                break
    return intersection


# convert given line in to rectangles considering boundaries
def convert_line_to_rectangle(p1, p2, id):
    length = sqrt((p2.x - p1.x) * (p2.x - p1.x) + (p2.y - p1.y) * (p2.y - p1.y))
    # extend to the length of d_lower/2 along the line x2,y2 and x4,y4 are new start and end points
    t1 = d_lower / (2 * length)
    t2 = (length + (d_lower / 2)) / length
    x2 = p1.x * (1 + t1) - t1 * p2.x
    y2 = p1.y * (1 + t1) - t1 * p2.y
    x4 = p1.x * (1 - t2) + t2 * p2.x
    y4 = p1.y * (1 - t2) + t2 * p2.y
    # now extend to d_lower/2 parallel to the line top and bottom
    if x2 - p1.x == 0:  # given line is parallel to y axis
        x5 = x2 - d_lower / 2
        x6 = x2 + d_lower / 2
        x7 = x4 - d_lower / 2
        x8 = x4 + d_lower / 2
        y5 = y2
        y6 = y2
        y7 = y4
        y8 = y4
    elif y2 - p1.y == 0:
        x5 = x2
        x6 = x2
        x7 = x4
        x8 = x4
        y5 = y2 + d_lower / 2
        y6 = y2 - d_lower / 2
        y7 = y4 + d_lower / 2
        y8 = y4 - d_lower / 2
    else:  # if the line is inclined, draw a circle from end point and draw a perpendicular. intersection points are  our limits
        m = (y2 - p1.y) / (x2 - p1.x)
        K = d_lower / (2 * (sqrt((1 + (m * m)))))
        x5 = x2 + (K * m)
        y5 = y2 - K
        x6 = x2 - (K * m)
        y6 = y2 + K
        x7 = x4 + (K * m)
        y7 = y4 - K
        x8 = x4 - (K * m)
        y8 = y4 + K

    r1 = Point(x5, y5)
    r2 = Point(x7, y7)
    r3 = Point(x8, y8)
    r4 = Point(x6, y6)
    return r1, r2, r3, r4, id


# Data preprocessing

map_data = numpy.loadtxt('C:/Users/MANOJ/Desktop/Efficient Linesegment Algorithms[1136]/map.mat')
data = pd.DataFrame(data=map_data)
data = data.to_numpy().T
_lines = [list(d) for d in list(data)]
lines = []
rectangles = []
min_distance = []
given_point = Point(700, 700)


def get_distance(start, end, given):
    return Distance((start.x, start.y), (end.x, end.y), (given.x, given.y))


for idx, l in enumerate(_lines):
    x1, x2, y1, y2 = l
    lines.append(Line(Point(x1, y1), Point(x2, y2), idx))
    distance = get_distance(Point(x1, y1), Point(x2, y2), given_point)
    if distance == sys.float_info.max:
        print("Invalid input given at column no:", idx, ", line cannot be formed")
    min_distance.append([distance, x1, y1, x2, y2, idx])
min_distance = sorted(min_distance, key=lambda m: m[0])
#print("1. The closest line to the given point is formed by points ", "S.", min_distance[0][5],
      #" ", min_distance[0][1], min_distance[0][2], " and ", min_distance[0][3], min_distance[0][4])
lines_x = sorted(lines, key=lambda l: l.p1.x)


# event to iterate sweepline
events = []
line_pairs = []
for idx, l in enumerate(lines_x):
    length = sqrt((l.p2.x - l.p1.x) * (l.p2.x - l.p1.x) + (l.p2.y - l.p1.y) * (l.p2.y - l.p1.y))
    if length != 0:
        a, b, c, d, e = convert_line_to_rectangle(l.p1, l.p2, l.idx)
        rectangles.append(Rectangle(l.p1, l.p2, a, b, c, d, e))
        # append the left and right points and there corresponding rectangle data
        events.append(
            [Rectangle(l.p1, l.p2, a, b, c, d, e).left_point, Rectangle(l.p1, l.p2, a, b, c, d, e).maximun_y, a, b, c,
             d, e])
        events.append(
            [Rectangle(l.p1, l.p2, a, b, c, d, e).right_point, Rectangle(l.p1, l.p2, a, b, c, d, e).maximun_y, a, b, c,
             d, e])
rectangles_x = sorted(rectangles, key=lambda r: r.right_point.x)
# events list for sweep learning algorithm sorted along x axis
events_x = sorted(events, key=lambda e: e[0].x)
start_time = time.time()
# create a bst tree
Tree = bst.BinarySearchTree()

# sweep learning algorithm
for i in events_x:
    # perform insert, compare and delete operation
    # key = y value = i[1], payload = [i[2],i[3],i[4],i[5],i[6]] = a,b,c,d,e = points of corresponding rectangle
    if i[0].isleft:  # if the event x is a leftmost point of certain rectangle
        # insert the rectangle in a tree sorted by its maximum y value
        Tree.insert_key(i[1], [i[2], i[3], i[4], i[5], i[6]])
        # get the predecessor and successor for the inserted rectangle and check for intersections
        # iterate through all predecessors and successors
        input_Predvalue = i[1]
        while Tree.getPredecessor(input_Predvalue) is not None:
            [a, [b, c, d, e, f]] = Tree.getPredecessor(input_Predvalue)
            pred = a
            if check_intersection(i[2], i[3], i[4], i[5], b, c, d, e) is True:
                line_pairs.append((i[6], f))
            else:
                limit_reached = True
            input_Predvalue = pred

        input_Scvalue = i[1]
        while Tree.getSuccessor(input_Scvalue) is not None:
            [a, [b, c, d, e, f]] = Tree.getSuccessor(input_Scvalue)
            succ = a
            if check_intersection(i[2], i[3], i[4], i[5], b, c, d, e) is True:
                line_pairs.append((i[6], f))
            else:
                limit_reached = True
            input_Scvalue = succ

    elif i[0].isright:  # if the event iterator reached rightmost point of a rectangle
        Tree.deleteKey(i[1])

print("The pairs of line segments Si,Sj whose relative distance is lower than given d_lower are:")
print(line_pairs)

'''
res = []
for i in range(len(line_pairs)):
    if line_pairs[i] not in res:
        res.append(line_pairs[i])
print(len(res))
'''

end_time = time.time()

# print("time ", end_time - start_time)
